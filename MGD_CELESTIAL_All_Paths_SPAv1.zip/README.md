# master.gabriels.dungeon — Masterpiece
- No-index meta; one-time consent (sigil saved) assumed; password gate remains unless remembered.
- Sanctum with areas; Mini-Sanctum per area; Spiral Flame Ritual with per-area overrides; Global/Area galleries with upload, show/hide, drag reorder.
- Edit thresholds via RITUAL_OVERRIDES in index.html.
